from .download_model import download_model

# Ensure the model is downloaded
download_model()
